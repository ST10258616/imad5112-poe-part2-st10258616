package com.example.imad5112_poe_st10258616

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var num1EditText: EditText
    private lateinit var num2EditText: EditText
    private lateinit var resultTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        num1EditText = findViewById(R.id.num1)
        num2EditText = findViewById(R.id.num2)
        resultTextView = findViewById(R.id.resultTextView)

        val addButton: Button = findViewById(R.id.addButton)
        val subtractButton: Button = findViewById(R.id.subtractButton)
        val multiplyButton: Button = findViewById(R.id.multiplyButton)
        val divideButton: Button = findViewById(R.id.divideButton)
        val squareRootButton: Button = findViewById(R.id.squareRootButton)
        val powerButton: Button = findViewById(R.id.powerButton)

        addButton.setOnClickListener { performOperation("+") }
        subtractButton.setOnClickListener { performOperation("-") }
        multiplyButton.setOnClickListener { performOperation("*") }
        divideButton.setOnClickListener { performOperation("/") }
        squareRootButton.setOnClickListener { performOperation("√") }
        powerButton.setOnClickListener { performOperation("^") }
    }

    private fun performOperation(operationSymbol: String) {
        val number1Str = num1EditText.text.toString()
        val number2Str = num2EditText.text.toString()

        if (number1Str.isEmpty() || number2Str.isEmpty()) {
            resultTextView.text = "Please enter both numbers"
            return
        }

        val number1 = number1Str.toDouble()
        val number2 = number2Str.toDouble()

        val result = when (operationSymbol) {
            "+" -> number1 + number2
            "-" -> number1 - number2
            "*" -> number1 * number2
            "/" -> {
                if (number2 != 0.0) {
                    number1 / number2
                } else {
                    resultTextView.text = "Error: Cannot divide by zero"
                    return
                }
            }
            "√" -> {
                if (number1 < 0) {
                    resultTextView.text = "Error: Cannot calculate square root of a negative number"
                    return
                }
                Math.sqrt(number1)
            }
            "^" -> Math.pow(number1, number2)
            else -> {
                resultTextView.text = "Invalid operation"
                return
            }
        }

        val formattedResult = if (result.isWhole()) {
            result.toInt().toString()
        } else {
            result.toString()
        }

        resultTextView.text = "$number1 $operationSymbol $number2 = $formattedResult"


    }

    private fun Double.isWhole() = this % 1 == 0.0

}
